package salesreport.tests;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import salesreport.Product;

/** Checks the total and average calculations using known sales figures. */
public class ProductTest {

    private Product createProductWithSampleSales() {
        String[] productNames = {
            "Cozy Nights Monarch mattress",
            "Restonic Barbados mattress",
            "Sealy Phuket mattress"
        };

        int[][] monthlySales = {
            {25, 18, 20},
            {15, 10, 12},
            {18, 15, 20}
        };

        return new Product(productNames, monthlySales);
    }

    @Test
    public void totalSalesWithSampleDataShouldBe153() {
        Product product = createProductWithSampleSales();
        assertEquals(153, product.GetTotalProductsSold());
    }

    @Test
    public void averageSalesWithSampleDataShouldBe17() {
        Product product = createProductWithSampleSales();
        assertEquals(17.0, product.GetAverageProductSold(), 0.001);
    }
}
