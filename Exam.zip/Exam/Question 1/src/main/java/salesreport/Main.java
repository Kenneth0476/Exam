package salesreport;

import java.util.Scanner;

/** Starts the program and collects the monthly sales figures. */
public class Main {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        String[] productNames = {
            "Cozy Nights Monarch mattress",
            "Restonic Barbados mattress",
            "Sealy Phuket mattress"
        };

        // Each row belongs to a product, and each column represents a month.
        int[][] monthlySales = new int[productNames.length][3];

        for (int product = 0; product < productNames.length; product++) {
            for (int month = 0; month < monthlySales[product].length; month++) {
                while (true) {
                    System.out.print("Enter sales for month " + (month + 1)
                            + " for " + productNames[product] + ": ");

                    if (input.hasNextInt()) {
                        int sales = input.nextInt();
                        if (sales >= 0) {
                            monthlySales[product][month] = sales;
                            break;
                        }
                        System.out.println("Please enter zero or a positive number.");
                    } else {
                        System.out.println("Please enter a whole number.");
                        input.next();
                    }
                }
            }
            System.out.println();
        }

        Product productCalculations = new Product(productNames, monthlySales);
        PrintProduct report = new PrintProduct(productCalculations);

        report.PrintHeading();
        report.PrintTotalProductSales();
        report.PrintAverageProductSales();
        report.PrintMostPopularProduct();

        input.close();
    }
}
