package salesreport;

/** Defines the sales calculations that a product report must provide. */
public interface IProduct {
    int GetTotalProductsSold();
    double GetAverageProductSold();
    String GetMostPopularProduct();
}
