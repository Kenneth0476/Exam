package salesreport;

/** Prints the sales calculations in a simple report format. */
public class PrintProduct {

    private final IProduct product;

    public PrintProduct(IProduct product) {
        this.product = product;
    }

    public void PrintHeading() {
        System.out.println("\nPRODUCT SALES REPORT - 2026");
        System.out.println("*******************************************");
    }

    public void PrintTotalProductSales() {
        System.out.println("TOTAL PRODUCT SALES: " + product.GetTotalProductsSold());
    }

    public void PrintAverageProductSales() {
        double averageSales = product.GetAverageProductSold();
        if (averageSales == Math.floor(averageSales)) {
            System.out.println("AVERAGE PRODUCT SALES: " + (int) averageSales);
        } else {
            System.out.println("AVERAGE PRODUCT SALES: " + String.format("%.2f", averageSales));
        }
    }

    public void PrintMostPopularProduct() {
        System.out.println("MOST POPULAR PRODUCT: " + product.GetMostPopularProduct());
    }
}
