package salesreport;

/** Stores the sales data and performs the calculations for the report. */
public class Product implements IProduct {

    private final String[] productNames;
    private final int[][] monthlySales;

    public Product(String[] productNames, int[][] monthlySales) {
        this.productNames = productNames;
        this.monthlySales = monthlySales;
    }

    /** Adds the sales figures for every product and month. */
    @Override
    public int GetTotalProductsSold() {
        int totalSales = 0;

        for (int[] productSales : monthlySales) {
            for (int monthlyTotal : productSales) {
                totalSales += monthlyTotal;
            }
        }

        return totalSales;
    }

    /** Returns the average of all the monthly sales figures entered. */
    @Override
    public double GetAverageProductSold() {
        int numberOfFigures = 0;

        for (int[] productSales : monthlySales) {
            numberOfFigures += productSales.length;
        }

        if (numberOfFigures == 0) {
            return 0;
        }

        return (double) GetTotalProductsSold() / numberOfFigures;
    }

    /** Finds the product with the highest combined sales across the months. */
    @Override
    public String GetMostPopularProduct() {
        if (productNames.length == 0 || monthlySales.length == 0) {
            return "No product data available";
        }

        int mostPopularIndex = 0;
        int highestSales = -1;

        for (int product = 0; product < monthlySales.length; product++) {
            int productTotal = 0;
            for (int monthlyTotal : monthlySales[product]) {
                productTotal += monthlyTotal;
            }

            if (productTotal > highestSales) {
                highestSales = productTotal;
                mostPopularIndex = product;
            }
        }

        return productNames[mostPopularIndex] + " (" + highestSales + ")";
    }
}
