package productapp;

public class ProductCalculations implements IProductCalculations {

    private static final double VAT_RATE = 0.15;        // 15% VAT
    private static final double COMMISSION_RATE = 0.05; // 5% commission

    private final double price;

    public ProductCalculations(double price) {
        this.price = price;
    }

    // Calculate 15% of the original price.
    @Override
    public double GetVat() {
        return price * VAT_RATE;
    }

    // Calculate 5% of the original price.
    @Override
    public double GetCommission() {
        return price * COMMISSION_RATE;
    }

    // Add VAT and commission to the original price.
    @Override
    public double GetTotal() {
        return price + GetVat() + GetCommission();
    }
}
